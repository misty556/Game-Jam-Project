using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;
using System.Collections.Generic;

namespace DialogueSystem
{
    public class DialogueUIView : MonoBehaviour
    {
        [Header("文本")]
        public TextMeshProUGUI nameText;
        public TextMeshProUGUI contentText;
        public GameObject namePanel;

        [Header("立绘")]
        public Image leftPortrait;
        public Image rightPortrait;

        [Header("对话框")]
        public CanvasGroup dialogueBoxGroup;
        public GameObject continueIcon;

        [Header("立绘表现")]
        [Tooltip("非说话角色的压暗程度（0=全黑，1=原色）")]
        [Range(0f, 1f)] public float dimFactor = 0.45f;

        [Tooltip("立绘淡入淡出速度")]
        public float portraitFadeSpeed = 6f;

        // 左右当前角色
        private DialogueCharacter _leftChar;
        private DialogueCharacter _rightChar;

        // 协程句柄，防止叠加
        private Coroutine _leftFadeCo;
        private Coroutine _rightFadeCo;

        // ---------- 对外接口 ----------

        public void ShowLine(DialogueLine line)
        {
            // 姓名
            if (line.IsNarration)
            {
                namePanel.SetActive(false);
            }
            else
            {
                namePanel.SetActive(true);
                nameText.text = line.speaker.characterName;
                nameText.color = line.speaker.nameColor;
            }

            // 正文（打字机接管，这里只设文本、清可见）
            contentText.text = line.text;
            contentText.maxVisibleCharacters = 0;

            // 立绘
            UpdatePortraits(line);

            // 对话框淡入
            dialogueBoxGroup.alpha = 1f;
        }

        public void SetVisibleCharacters(int count)
        {
            contentText.maxVisibleCharacters = count;
        }

        public void SetContinueIcon(bool visible)
        {
            if (continueIcon != null)
                continueIcon.SetActive(visible);
        }

        public void Hide()
        {
            dialogueBoxGroup.alpha = 0f;
            SetContinueIcon(false);

            // 可选：对话结束时让立绘也淡出
            if (_leftChar != null) StartFade(leftPortrait, 0f, isLeft: true, fadeAlpha: true);
            if (_rightChar != null) StartFade(rightPortrait, 0f, isLeft: false, fadeAlpha: true);
        }

        // ---------- 内部逻辑 ----------

        private void UpdatePortraits(DialogueLine line)
        {
            if (line.speaker == null) return;

            if (line.side == PortraitSide.Left)
                UpdateOneSide(line, isLeft: true);
            else
                UpdateOneSide(line, isLeft: false);
        }

        private void UpdateOneSide(DialogueLine line, bool isLeft)
        {
            Image targetImg = isLeft ? leftPortrait : rightPortrait;
            Image oppositeImg = isLeft ? rightPortrait : leftPortrait;

            DialogueCharacter currentChar = isLeft ? _leftChar : _rightChar;
            DialogueCharacter oppositeChar = isLeft ? _rightChar : _leftChar;

            // 1) 目标侧：切换角色或换表情
            if (currentChar != line.speaker)
            {
                // 换角色 → 先设 sprite 再淡入
                if (isLeft) _leftChar = line.speaker;
                else _rightChar = line.speaker;

                targetImg.sprite = line.speaker.GetPortrait(line.expression);
                targetImg.gameObject.SetActive(true);

                // 起始 alpha = 0 → 淡入到 1
                var c = targetImg.color;
                c.a = 0f;
                targetImg.color = c;
                StartFade(targetImg, 1f, isLeft);
            }
            else
            {
                // 同一角色 → 直接换表情，不重播淡入
                targetImg.gameObject.SetActive(true);   // ← 补这句，防止上次 Hide() 把它关掉了
                targetImg.sprite = line.speaker.GetPortrait(line.expression);
                StartFade(targetImg, 1f, isLeft, fadeAlpha: false);
            }

            // 2) 非说话侧压暗
            if (oppositeChar != null)
            {
                StartFade(oppositeImg, dimFactor, isLeft: !isLeft, fadeAlpha: false);
            }

            // 3) 高亮说话人姓名颜色（可选，UI 里更明显）
            if (!line.IsNarration)
                nameText.color = line.speaker.nameColor;
        }

        /// <summary>
        /// 启动一次淡入/淡出
        /// </summary>
        /// <param name="img">目标 Image</param>
        /// <param name="targetValue">目标值</param>
        /// <param name="isLeft">是否为左侧（用于终止旧协程）</param>
        /// <param name="fadeAlpha">
        /// true  → 渐变 alpha（真正的淡入淡出）
        /// false → 只渐变整体亮度（用于高亮/压暗）
        /// </param>
        private void StartFade(Image img, float targetValue, bool isLeft, bool fadeAlpha = true)
        {
            // 终止该侧旧协程
            if (isLeft && _leftFadeCo != null) StopCoroutine(_leftFadeCo);
            if (!isLeft && _rightFadeCo != null) StopCoroutine(_rightFadeCo);

            var co = StartCoroutine(FadeRoutine(img, targetValue, fadeAlpha));
            if (isLeft) _leftFadeCo = co;
            else _rightFadeCo = co;
        }

        private IEnumerator FadeRoutine(Image img, float targetValue, bool fadeAlpha)
        {
            Color c = img.color;

            float startA = c.a;
            float startRGB = c.r; // r/g/b 同步缩放，假设原色是白色 1,1,1

            float t = 0f;
            while (t < 1f)
            {
                t += Time.deltaTime * portraitFadeSpeed;
                float lerp = Mathf.Clamp01(t);

                if (fadeAlpha)
                {
                    c.a = Mathf.Lerp(startA, targetValue, lerp);
                }
                else
                {
                    // 高亮/压暗：只动 RGB，alpha 保持
                    float v = Mathf.Lerp(startRGB, targetValue, lerp);
                    c.r = c.g = c.b = v;
                    c.a = 1f;
                }

                img.color = c;
                yield return null;
            }

            // 保证最终值精确
            if (fadeAlpha)
            {
                c.a = targetValue;
                if (Mathf.Approximately(targetValue, 0f))
                    img.gameObject.SetActive(false);
            }
            else
            {
                c.r = c.g = c.b = targetValue;
                c.a = 1f;
            }
            img.color = c;
        }
    }
}